---
title: Access Restrictions
weight: 10
---

# Access Restrictions

This section contains 1 API endpoint(s).

- [Blocked IP or identifier - Access denied](blocked-ip-or-identifier-access-denied) - `POST /api/v1/verify`
