---
title: Get Product Changelog
weight: 10
---



## Description

Public endpoint (no authentication required) to fetch the changelog for a specific product.

## Endpoint Details

- **Method:** `GET`
- **Path:** `/api/v1/products/:slug/changelog`
- **Authentication:** API Key (required)

## Request Headers

None specified in Postman

## Request Parameters

None

## Response Examples

⚠️ **No response examples** are documented in the Postman collection for this endpoint.
