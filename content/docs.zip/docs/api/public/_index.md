---
title: Public Endpoints
weight: 10
---

# Public Endpoints

This section contains 1 API endpoint(s).

- [Get Product Changelog](get-product-changelog) - `GET /api/v1/products/:slug/changelog`
